# ITC React Static AI Chatbot

React + Vite. No Django and no backend. Uses the supplied ITC logo and can call Groq or OpenRouter directly from the browser.

## Run
npm install

Copy `.env.example` to `.env`, set the provider and API key, then:

npm run dev

## Groq
VITE_AI_PROVIDER=groq
VITE_GROQ_API_KEY=YOUR_KEY
VITE_GROQ_MODEL=llama-3.3-70b-versatile

## OpenRouter
VITE_AI_PROVIDER=openrouter
VITE_OPENROUTER_API_KEY=YOUR_KEY
VITE_OPENROUTER_MODEL=openrouter/auto

## Security
This is intentionally a static client-side implementation. VITE_* values are bundled into the browser, so the API key is visible to users. Do not use a real unrestricted key on a public production site. For production, use a backend/serverless proxy.
