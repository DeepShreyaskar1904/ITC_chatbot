import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { Minus, X, Send, Trash2 } from "lucide-react";
import "./styles.css";

/* =========================================
   AI PROVIDER CONFIGURATION
========================================= */

const provider = (
  import.meta.env.VITE_AI_PROVIDER || "groq"
).toLowerCase();

const config =
  provider === "openrouter"
    ? {
        url: "https://openrouter.ai/api/v1/chat/completions",
        key: import.meta.env.VITE_OPENROUTER_API_KEY,
        model:
          import.meta.env.VITE_OPENROUTER_MODEL || "openrouter/auto",
      }
    : {
        url: "https://api.groq.com/openai/v1/chat/completions",
        key: import.meta.env.VITE_GROQ_API_KEY,
        model:
          import.meta.env.VITE_GROQ_MODEL ||
          "llama-3.3-70b-versatile",
      };

/* =========================================
   SYSTEM PROMPT
========================================= */

const system = `
You are ITC AI Assistant.

Be helpful, accurate, professional and concise.

For technical questions:
- Explain step by step.
- Use simple language.
- Give practical examples when useful.

If you are unsure about something, say so instead of inventing facts.
`;

/* =========================================
   APP
========================================= */

function App() {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  const [messages, setMessages] = useState([
    {
      id: crypto.randomUUID(),
      role: "assistant",
      content: "Hello! 👋\nHow can I help you today?",
    },
  ]);

  const end = useRef(null);
  const input = useRef(null);

  /* =========================================
     AUTO SCROLL
  ========================================= */

  useEffect(() => {
    if (end.current) {
      end.current.scrollIntoView({
        behavior: "smooth",
        block: "nearest",
      });
    }
  }, [messages, busy]);

  /* =========================================
     AUTO FOCUS WHEN CHAT OPENS
  ========================================= */

  useEffect(() => {
    if (!open) return;

    const timer = setTimeout(() => {
      input.current?.focus();
    }, 150);

    return () => {
      clearTimeout(timer);
    };
  }, [open]);

  /* =========================================
     TEXTAREA RESIZE
  ========================================= */

  const resize = () => {
    if (!input.current) return;

    input.current.style.height = "auto";

    input.current.style.height =
      Math.min(input.current.scrollHeight, 110) + "px";
  };

  /* =========================================
     SEND MESSAGE
  ========================================= */

  async function send() {
    const q = text.trim();

    if (!q || busy) return;

    /* API KEY CHECK */

    if (
      !config.key ||
      config.key.startsWith("PASTE_")
    ) {
      setMessages((m) => [
        ...m,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content:
            "⚠️ API key is not configured. Add it to your .env file and restart Vite.",
        },
      ]);

      return;
    }

    /* USER MESSAGE */

    const user = {
      id: crypto.randomUUID(),
      role: "user",
      content: q,
    };

    const next = [...messages, user];

    setMessages(next);
    setText("");

    if (input.current) {
      input.current.style.height = "auto";
    }

    setBusy(true);

    try {
      /* =========================================
         API REQUEST
      ========================================= */

      const response = await fetch(config.url, {
        method: "POST",

        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.key}`,

          ...(provider === "openrouter"
            ? {
                "HTTP-Referer": window.location.href,
                "X-Title": "ITC AI Assistant",
              }
            : {}),
        },

        body: JSON.stringify({
          model: config.model,

          messages: [
            {
              role: "system",
              content: system,
            },

            ...next
              .slice(-10)
              .map(({ role, content }) => ({
                role,
                content,
              })),
          ],

          temperature: 0.7,
        }),
      });

      /* =========================================
         SAFE JSON RESPONSE
      ========================================= */

      const contentType =
        response.headers.get("content-type") || "";

      let data;

      if (contentType.includes("application/json")) {
        data = await response.json();
      } else {
        const raw = await response.text();

        throw new Error(
          `Server returned ${response.status}: ${raw.slice(
            0,
            200
          )}`
        );
      }

      /* =========================================
         API ERROR
      ========================================= */

      if (!response.ok) {
        throw new Error(
          data?.error?.message ||
            `API request failed (${response.status})`
        );
      }

      /* =========================================
         AI RESPONSE
      ========================================= */

      const answer =
        data?.choices?.[0]?.message?.content;

      if (!answer) {
        throw new Error("Empty AI response");
      }

      setMessages((m) => [
        ...m,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content: answer,
        },
      ]);
    } catch (error) {
      console.error("ITC AI Error:", error);

      setMessages((m) => [
        ...m,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content: `⚠️ ${
            error?.message ||
            "Something went wrong. Please try again."
          }`,
        },
      ]);
    } finally {
      setBusy(false);

      setTimeout(() => {
        input.current?.focus();
      }, 30);
    }
  }

  /* =========================================
     CLEAR CHAT
  ========================================= */

  const clear = () => {
    setMessages([
      {
        id: crypto.randomUUID(),
        role: "assistant",
        content:
          "Chat cleared. 👋\nHow can I help you?",
      },
    ]);
  };

  /* =========================================
     UI
  ========================================= */

  return (
    <>
      {/* =====================================
          FLOATING CHAT BUTTON
      ===================================== */}

      {!open && (
        <button
          className="float"
          onClick={() => setOpen(true)}
          aria-label="Open ITC chatbot"
        >
          <img src="/itc.jpg" alt="ITC" />
        </button>
      )}

      {/* =====================================
          CHAT WINDOW
      ===================================== */}

      <section
        className={`chat ${open ? "open" : ""}`}
        aria-hidden={!open}
      >
        {/* HEADER */}

        <header>
          <div className="info">
            <div className="logo">
              <img src="/itc.jpg" alt="ITC" />
            </div>

            <div>
              <h2>ITC AI Assistant</h2>

              <span>
                <i />
                Online
              </span>
            </div>
          </div>

          <div className="actions">
            {/* CLEAR */}

            <button
              onClick={clear}
              title="Clear chat"
              aria-label="Clear chat"
            >
              <Trash2 size={16} />
            </button>

            {/* MINIMIZE */}

            <button
              onClick={() => setOpen(false)}
              title="Minimize"
              aria-label="Minimize chatbot"
            >
              <Minus size={19} />
            </button>

            {/* CLOSE */}

            <button
              onClick={() => setOpen(false)}
              title="Close"
              aria-label="Close chatbot"
            >
              <X size={18} />
            </button>
          </div>
        </header>

        {/* =====================================
            MESSAGES
        ===================================== */}

        <main className="messages">
          {messages.map((message) => {
            if (message.role === "user") {
              return (
                <div
                  className="user"
                  key={message.id}
                >
                  <div>{message.content}</div>
                </div>
              );
            }

            return (
              <div
                className="bot"
                key={message.id}
              >
                <div className="avatar">
                  <img
                    src="/itc.jpg"
                    alt="ITC"
                  />
                </div>

                <div className="wrap">
                  <small>ITC Assistant</small>

                  <div
                    className="bubble"
                    dangerouslySetInnerHTML={{
                      __html: format(
                        message.content
                      ),
                    }}
                  />
                </div>
              </div>
            );
          })}

          {/* =====================================
              THINKING INDICATOR
          ===================================== */}

          {busy && (
            <div className="bot">
              <div className="avatar">
                <img
                  src="/itc.jpg"
                  alt="ITC"
                />
              </div>

              <div className="wrap">
                <small>ITC Assistant</small>

                <div className="bubble dots">
                  <i />
                  <i />
                  <i />
                </div>
              </div>
            </div>
          )}

          <div ref={end} />
        </main>

        {/* =====================================
            INPUT
        ===================================== */}

        <footer>
          <textarea
            ref={input}
            value={text}
            rows="1"
            maxLength="4000"
            placeholder="Type your message..."
            disabled={busy}
            onChange={(e) => {
              setText(e.target.value);
              resize();
            }}
            onKeyDown={(e) => {
              if (
                e.key === "Enter" &&
                !e.shiftKey
              ) {
                e.preventDefault();
                send();
              }
            }}
          />

          <button
            onClick={send}
            disabled={!text.trim() || busy}
            aria-label="Send"
          >
            <Send size={18} />
          </button>
        </footer>
      </section>
    </>
  );
}

/* =========================================
   MESSAGE FORMATTER
========================================= */

function format(value) {
  const div = document.createElement("div");

  /*
    Escape HTML first.
    This prevents AI response HTML from
    being directly executed.
  */

  div.textContent = value;

  return div.innerHTML
    .replace(
      /\*\*(.*?)\*\*/g,
      "<strong>$1</strong>"
    )
    .replace(
      /`([^`]+)`/g,
      "<code>$1</code>"
    )
    .replace(
      /\n/g,
      "<br/>"
    );
}

/* =========================================
   ROOT
========================================= */

const rootElement =
  document.getElementById("root");

if (rootElement) {
  createRoot(rootElement).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}